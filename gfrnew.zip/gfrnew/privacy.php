<!DOCTYPE html>
<html>

<head>
    <!-- Google Tag Manager -->
    <!-- End Google Tag Manager -->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GFR | Privacy Policy</title>
    <meta name="keywords" content="">
    <meta name="">
    <!-- <link rel="icon" href="images/favicon.png" type="image/png" sizes="16x16"> -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"
        integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css?v=1.0" rel="stylesheet" type="text/css">
    <link href="lightbox/light-box.css" rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/animate.min.css">
</head>

<body>
    <!-- Google Tag Manager (noscript) -->
    <!-- End Google Tag Manager (noscript) -->

    <header id="home">
        <nav class="navbar navbar-default thank-menu" id="hide-menu">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                        data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">
                        <img src="images/logo.png">
                    </a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="index.php" class="m-link">Home</a></li>
                        <li><a href="index.php" class="m-link">About Us</a></li>
                        <li><a href="index.php" class="m-link">Configuration</a></li>
                        <li><a href="index.php" class="m-link">Amenities</a></li>
                        <li><a href="index.php" class="m-link">Gallery</a></li>
                        <li><a href="index.php" class="m-link">Contact Us</a></li>
                        <!-- <li class="hidden-xs">
                            <a href="javascript:void (0);" class="nav-call">
                                <span class="glyphicon glyphicon-phone" aria-hidden="true"></span>
                                022 6144 6633
                            </a>
                        </li> -->
                        <!--<li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Dropdown <span class="caret"></span></a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Action</a></li>
                            <li><a href="#">Another action</a></li>
                            <li><a href="#">Something else here</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="#">Separated link</a></li>
                        </ul>
                    </li>-->
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>
    </header>

    <section class="inner-banner">
        <div class="container">
            <div class="banner-txt-thank">
                <h1>Privacy Policy</h1>
            </div>
        </div>
    </section>


    <section class="glob-sec">
        <div class="container">
            <h2 class="terms-head">Privacy Policy</h2>
            <p>
                Get Fit with Rihana, hereinafter referred to as GFR attaches great importance to the protection of your
                data and the protection of your privacy. In the following, you will be thus informed about the
                collection and use of personal data while using the website. </p>

            <div style="width: 100%;height: 40px;"></div>

            <!-- <h2 class="terms-head">Privacy Policy</h2> -->
            <p>
                <b>Anonymous data collection </b><br>
                You can visit the website without giving any information about yourself. GFR does not store any personal
                data in this context. In order to improve the supply, only statistical data are evaluated which do not
                allow conclusions to be drawn about your person.
            </p>
            <p>
                <b>Collection, processing and usage of personal data </b><br>
                All personal information you provide us or that we obtain will be handled by GFR and we will be
                responsible for the secure storage of your personal information. We will collect details such as contact
                name, contact number and email address and this information is obtained automatically through forms
                annotated on www.getfitwithrihana.com The personal information you provide will be used to provide
                offers and information about our services to you. The information you provide is only available to Get
                Fit with Rihana, and will not be shared with any other third parties within India or internationally. By
                visiting this website and subscribing to our services, you agree to the above.
            </p>


            <p>
                <b>Collection, processing and usage of payment data </b><br>
                All other information such as payment details is not collected by our company and we are therefore not
                responsible for the security of such information. Payment information is processed using a third party
                company, RazorPay. This company can be contacted at www.razorpay.com.
            </p>

            <p>
                <b>Cookies </b><br>
                The website uses so-called cookies. Cookies are text files which are stored on your computer and which
                your browser saves. They are designed to make our supply more user-friendly, more effective and safer.
                Furthermore, the website's cookies allow for recognition of your browser and providing you with
                services. Cookies do not contain personal data. Some of the used cookies will be deleted after the end
                of the browser session, so after closing your browser (so-called session cookies). Other cookies remain
                on your device and allow us to recognize your browser during the next visit (persistent cookies). You
                can set your browser to inform you about the setting of cookies, to decide on their acceptance, or to
                exclude the acceptance of cookies for specific cases or in general. If the cookies are not accepted, the
                functionality of our website may be restricted.
            </p>

            <p>
                <b>Google Analytics </b><br>
                This website uses Google Analytics, a web analytics service provided by Google, Inc. ("Google"). Google
                Analytics uses so-called "cookies", text files that are stored on your computer and which allow an
                analysis of the use of the website by you. The information generated by the cookie about your use of
                this website is generally transferred to a Google server in the USA and stored there. Only in
                exceptional cases will the full IP address be transferred to a Google server in the US and abbreviated
                there. On behalf of the operator of this website, Google will use this information to evaluate your use
                of the website, to compile reports on website activity, and to provide other services connected with the
                use of the website and the internet usage to the website operator. The IP address provided by your
                browser as part of Google Analytics will not be merged with other Google data. You can prevent cookies
                from being saved by setting your browser software accordingly; However, we would point out that in this
                case you may not be able to fully utilize all the functions of this website. In addition, you can
                prevent Google's processing of personal data (including your IP address) generated by the cookie and
                your use of the website as well as the processing of this data by Google by installing and using the
                browser plug-in available under the following link: http://tools.google.com/dlpage/gaoptout?hl=de.
            </p>


            <p>
                <b>Third Party Services </b><br>
                In general, the third-party providers used by us will only collect, use and disclose your information to
                the extent necessary to allow them to perform the services they provide to us. However, certain
                third-party service providers, such as payment gateways and other payment transaction processors, have
                their own privacy policies in respect to the information we are required to provide to them for your
                purchase-related transactions. For these providers, we recommend that you read their privacy policies so
                you can understand the manner in which your personal information will be handled by these providers. In
                particular, remember that certain providers may be located in or have facilities that are located a
                different jurisdiction than either you or us. So if you elect to proceed with a transaction that
                involves the services of a third-party service provider, then your information may become subject to the
                laws of the jurisdiction(s) in which that service provider or its facilities are located. As an example,
                if you are located in Canada and your transaction is processed by a payment gateway located in the
                India, then your personal information used in completing that transaction may be subject to disclosure
                under Indian judiciary. Once you leave our website or are redirected to a third-party website or
                application, you are no longer governed by this Privacy Policy or our website’s Terms of Service.
            </p>

            <p>
                <b>External Links </b><br>
                Some links on our website may direct you away from our site. We are not responsible for the privacy
                practices of other sites and encourage you to read their privacy statements.
            </p>

            <p>
                <b>Security </b><br>
                To protect your personal information, we take reasonable precautions and follow industry best practices
                to make sure it is not inappropriately lost, misused, accessed, disclosed, altered or destroyed. If you
                provide us with your credit card information, the information is encrypted using secure socket layer
                technology (SSL) and stored with a AES-256 encryption. Although no method of transmission over the
                Internet or electronic storage is 100% secure, we follow all PCI-DSS requirements and implement
                additional generally accepted industry standards.
            </p>

            <p>
                <b>Age of Consent </b><br>
                By using this site, you represent that you are at least the age of majority in your state or province of
                residence, or that you are the age of majority in your state or province of residence and you have given
                us your consent to allow any of your minor dependents to use this site.
            </p>

            <p>
                <b>Changes to this Privacy Policy </b><br>
                We reserve the right to modify this privacy policy at any time, so please review it frequently. Changes
                and clarifications will take effect immediately upon their posting on the website.
            </p>



        </div>
    </section>


    <section class="footer-sec" id="footer">
        <div class="container">
            <div class="foote-wrap">
                <img src="images/logo.png">
                <!--<img class="head-icon" src="images/head-icon.png">-->

                <div class="contacwrap">
                    <p>
                        For any inquiries, questions, or to register your interest, please contact us using the details
                        below
                    </p>

                    <!-- <ul class="address">
                        <li><i class="fas fa-phone"></i> 022 6144 6641</li>
                        <li><i class="fas fa-building"></i>GFR, Goregaon Mulund Link
                            Road, Near Fortis Hospital, Mulund (West), Mumbai - 400 080
                        </li>
                    </ul> -->
                    <ul class="reralist">
                        <li><img class="whatsapp" src="images/whatsapp.png" style="">&nbsp; <a href="tel:+919321490890"
                                class="fix-link"><b>+919321490890</b></li>

                    </ul>

                    <div class="address-line"></div>


                    <!-- <div style="width: 100%;height: 30px;"></div> -->

                    <ul class="partner">
                        <li><a href="https://www.instagram.com/getfitwithrihana/" target="_blank"> <img
                                    src="images/linkedin.png"></a></li>
                        <li><a href="https://www.facebook.com/getfitwithrihana" target="_blank"><img
                                    src="images/facebook.png" class=""></a></li>
                        <li><a href="https://www.youtube.com/channel/UCFB67EsuhivAYAdDpyl_V8Q/featured"
                                target="_blank"><img src="images/youtube.png" class=""></a></li>

                    </ul>

                    <div style="width: 100%;height: 30px;"></div>

                    <p class="copy-right">© GFR All Rights Reserved 2020.</p>

                </div>

            </div>
        </div>
    </section>




    <script src="js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="lightbox/light-box.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/wow.js"></script>

    <script src="js/jquery.validate.js"></script>
    <script src="js/mobilevalidate.js"></script>
    <script src="js/cookie.js"></script>
    <script src="js/popout.js"></script>


    <script>
    jQuery(document).ready(function($) {
        var $floor = $('.f-box a').simpleLightbox();
        //        $('.offer-btn').simpleLightbox();
        //        $('.map-btn').simpleLightbox();
    });
    </script>

    <script type="text/javascript">
    jQuery(document).ready(function($) {
        Delete_Cookie('formfilled');
        // ---------------for model only-----
        $(".click-price").click(function() {
            $('#price-model').modal('show');
        });

        $(".interested").click(function() {
            $('#interested').modal('show');
        });
        $(".i-am").click(function() {
            $('#interested').modal('show');
        });

    });
    </script>

    <script>
    jQuery(document).ready(function($) {
        // Add smooth scrolling to all links
        $(".m-link").on('click', function(event) {

            // Make sure this.hash has a value before overriding default behavior
            if (this.hash !== "") {
                // Prevent default anchor click behavior
                event.preventDefault();

                // Store hash
                var hash = this.hash;

                // Using jQuery's animate() method to add smooth page scroll
                // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area

                $('html, body').animate({
                    scrollTop: $(hash).offset().top
                }, 800, function() {
                    // Add hash (#) to URL when done scrolling (default click behavior)
                    // window.location.hash = hash;
                });
            } // End if
        });

        $('.navbar-nav li').on('click', function() {
            $('.navbar-nav li.active').removeClass('active');
            $(this).addClass('active');
        });
        $(document).on('click', '.navbar-collapse.in', function(e) {
            if ($(e.target).is('a') && ($(e.target).attr('class') != 'dropdown-toggle')) {
                $(this).collapse('hide');
            }
        });
    });
    </script>


    <script type="text/javascript">
    function save_landing_pageinfo(elm) {
        jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', true);
        setTimeout(function() {
            jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', false);
        }, 5000);
        var name = jQuery('#' + elm + ' input[name="fname"]').val();
        var mobileno = jQuery('#' + elm + ' input[name="mobile"]').val();
        var emailid = jQuery('#' + elm + ' input[name="email"]').val();
        var message = jQuery('#' + elm + ' textarea[name="message"]').val();
        var fsource = jQuery('#' + elm + ' input[name="source"]').val();
        var current_url = location.hostname;

        if (name == "") {
            //alert("Please Enter Your Name");
            return false;
        }

        mobileno = mobileno.replace(/[^0-9]/g, '');
        if (mobileno.length != 10) {
            //alert("Please Enter 10 Digit Mobile Number");
            return false;
        }

        if (elm == 'price-popup') {
            emailid = "";
        } else if (elm == 'main-popup') {
            emailid = "";
        } else {
            var atpos = emailid.indexOf("@");
            var dotpos = emailid.lastIndexOf(".");
            if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= emailid.length) {
                return false;
            }
        }

        if (message == undefined) {
            message = "";
        }

        if (name != "" && mobileno != "") {
            $("#pageloader").fadeIn();
            var tags = 'Atmosphere';
            var webToLeadData = {
                'firstname': name,
                'email': emailid,
                'mobile': mobileno,
                'tags': tags,
                'cstm_fsource': fsource,
                'cstm_current_url': current_url
            };


            MTI.webToLead(webToLeadData,
                function() {
                    submitForm(elm);
                },
                function(respone) {
                    console.log(respone);
                    submitForm(elm);
                }
            );
        }


        return false;
    }

    function submitForm(elm) {
        document.createElement('form').submit.call(document.getElementById(elm));
    }
    </script>

</body>

</html>