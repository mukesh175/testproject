<?php
date_default_timezone_set('Asia/Kolkata');
require 'PHPMailerAutoload.php';
include_once 'helperClass.php';


/**
 * Description of emailClass
 *
 * @author admin
 */
class EmailClass
{
//NOTE : please delete << and >> sign after replacing with actual value

    var $fromname = 'GFR ';
    var $fromemail = 'marketing@realatte.com';
    // var $bcc = array('rohan@realatte.com', 'rahul@realatte.com');
    var $PageUrl = 'GFR ';
    var $emailRecipients = array('siddharth@realatte.com');


// public function defaultTo() {
//     return array('marketing@happyheap.com');
// }

    // public function defaultReplyTo() {
    //   return 'sales@gaganunnatii.com';
    // }

    public function sendMail($params)
    {
        $fromName = $this->fromname;
        $fromEmail = $this->fromemail;
        $bcc = $this->bcc;

        $toEmail = $this->emailRecipients;

        // $replyToEmail = $this->defaultReplyTo();

        //Create a new PHPMailer instance
        $mail = new PHPMailer();

        //Tell PHPMailer to use SMTP
        $mail->isSMTP();

        //Enable SMTP debugging
        // 0 = off (for production use)
        // 1 = client messages
        // 2 = client and server messages
        $mail->SMTPDebug = 0;

        //Ask for HTML-friendly debug output
        $mail->Debugoutput = 'html';

        //Set the hostname of the mail server
        $mail->Host = 'smtp.gmail.com';     // NOTE: for gmail smtp is-> smtp.gmail.com

        //Set the SMTP port number - 587 for authenticated TLS, a.k.a. RFC4409 SMTP submission
        $mail->Port = 587;

        //Set the encryption system to use - ssl (deprecated) or tls
        $mail->SMTPSecure = 'tls';

        //Whether to use SMTP authentication
        $mail->SMTPAuth = true;

        //Username to use for SMTP authentication - use full email address for gmail
        $mail->Username = "marketing@realatte.com";

        //Password to use for SMTP authentication
        $mail->Password = "rl@12345";

        //Set who the message is to be sent from
        $mail->setFrom($fromEmail, $fromName);

        //Set an alternative reply-to address
        // $mail->addReplyTo($replyToEmail, $fromName);

        //Set who the message is to be sent to
        foreach ($toEmail as $email) {
            $mail->addAddress($email);
        }

        foreach ($bcc as $email) {
            $mail->addBCC($email);
        }

        //Set the subject line
        $mail->Subject = $params['subject'];

        //Read an HTML message body from an external file, convert referenced images to embedded,
        //convert HTML into a basic plain-text alternative body
        //$mail->msgHTML(file_get_contents('contents.html'), dirname(__FILE__));
        $mail->Body = $params['messageBody'];

        //Set to sent content as HTML
        $mail->IsHTML(true);

        //Replace the plain text body with one created manually
        //$mail->AltBody = $params['messageBody'];
        //Attach an image file
        //$mail->addAttachment('images/phpmailer_mini.png');
        //echo "<pre>"; print_r($mail); echo "</pre>";die();
        //send the message, check for errors
        if (!$mail->send()) {
            echo "Mailer Error: " . $mail->ErrorInfo;
            echo "<br />";
            return false;
        } else {
            //echo "Message sent!";
            //header("Location: http://" . $this->defaultUrl . "/thank-you.php");
            return true;
        }
    }

    public function getLeadDetails()
    {

        $keyword = $_COOKIE['cstm_ppc_keyword'];
        $channel = $_COOKIE['cstm_ppc_channel'];
        $campaign = $_COOKIE['cstm_ppc_campaign'];
        $placement = $_COOKIE['cstm_ppc_placement'];
        $device = $_COOKIE['cstm_ppc_device'];

        $lead .= '<tr><td>Keyword:</td><td>' . $keyword . '</td></tr>';
        $lead .= '<tr><td>Channel:</td><td>' . $channel . '</td></tr>';
        $lead .= '<tr><td>Campaign:</td><td>' . $campaign . '</td></tr>';
        $lead .= '<tr><td>Placement:</td><td>' . $placement . '</td></tr>';
        $lead .= '<tr><td>Device:</td><td>' . $device . '</td></tr>';

        return $lead;
    }

    public function callback()
    {

        $keyword = $_COOKIE['cstm_ppc_keyword'];
        $channel = $_COOKIE['cstm_ppc_channel'];
        $campaign = $_COOKIE['cstm_ppc_campaign'];
        $placement = $_COOKIE['cstm_ppc_placement'];
        $device = $_COOKIE['cstm_ppc_device'];
        $channel_id = $_COOKIE['channel_id'];

        $fname = $_REQUEST['fname'];
        $lname = $_REQUEST['lname'];
        $email = $_REQUEST['email'];
        $mobile = str_replace(' ', '', $_REQUEST['mobile']);
        $source = $_REQUEST['source'];
        $message = $_REQUEST['message'];
        $country_code = $_REQUEST['country_code'];
        $visit_from = $_REQUEST['visit_from'];
        $name = $fname . ' ' . $lname;
        $fullmobile = "91" . $mobile;

        $leadDetails = $this->getLeadDetails();


        // Google Sheet Interation------------------

        $postFields = "entry.449648499=" . $name;
        $postFields .= "&entry.1379833540=" . $email;
        $postFields .= "&entry.758332158=" . $fullmobile;
        $postFields .= "&entry.1900106466=" . $message;
        $postFields .= "&entry.1693361781=" . $source;
        $postFields .= '&entry.1830911442=' . urlencode($_COOKIE['cstm_ppc_campaign']);
        $postFields .= '&entry.939490048=' . urlencode($_COOKIE['cstm_ppc_channel']);
        $postFields .= '&entry.729166844=' . urlencode($_COOKIE['cstm_ppc_keyword']);
        $postFields .= '&entry.839903606=' . urlencode($_COOKIE['cstm_ppc_placement']);
        $postFields .= '&entry.2003337495=' . urlencode($_COOKIE['cstm_ppc_device']);

        $ch1 = curl_init();
        curl_setopt($ch1, CURLOPT_URL, "https://docs.google.com/forms/u/0/d/e/1FAIpQLSewT0HjIeSGmBJ76e9wFejpUHBjyt8_Ly8AQUr98_MwWot0Aw/formResponse");
        curl_setopt($ch1, CURLOPT_POST, 1);
        curl_setopt($ch1, CURLOPT_POSTFIELDS, $postFields);
        curl_setopt($ch1, CURLOPT_HEADER, 0);
        curl_setopt($ch1, CURLOPT_RETURNTRANSFER, true);
        //print_r($hash);
        // $result1 = curl_exec($ch1);








        if ($source === 'Enquiry Form') {
            //var_dump($mobile);die;
            //setcookie('popout', 'it works');
            if (EmailClass::validationCheckMobile($mobile) === true) {

                $body .= '<html>';
                $body .= '<body style="font-size: 11; font-family: Verdana;">';
                $body .= '<h3 style="color:#e91e63;"> Greetings from GFR , </h3>';
                $body .= '<p> Thank you for expressing interest on our website. Our expert will get in touch with you shortly. </p>';
                $body .= '<br/>';
                $body .= '<table style="font-size: 11; font-family: Verdana;">';
                $body .= '<tr><td>Name:</td><td>' . $name . '</td></tr>';
                $body .= '<tr><td>Email:</td><td>' . $email . '</td></tr>';
                $body .= '<tr><td>Mobile:</td><td>' . $mobile . '</td></tr>';
                $body .= '<tr><td>Source:</td><td>' . $source . '</td></tr>';
                $body .= $leadDetails;
                $body .= '</table>';
                $body .= '<br></br>';
                $body .= 'Regards';
                $body .= '<br></br>';
                $body .= $this->fromname;
                $body .= '<br></br>';
                $body .= '</body>';
                $body .= '</html>';
                $params['messageBody'] = $body;
                $params['subject'] = 'GFR  Enquiry Form';

                // Send Mail
                if ($this->sendMail($params)) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } elseif ($source === 'Floor Plan') {

            if (EmailClass::validationCheckMobile($mobile) === true) {

                $body .= '<html>';
                $body .= '<body style="font-size: 11; font-family: Verdana;">';
                $body .= '<h3 style="color:#e91e63;"> Greetings from GFR , </h3>';
                $body .= '<p> Thank you for expressing interest on our website. Our expert will get in touch with you shortly. </p>';
                $body .= '<br/>';
                $body .= '<table style="font-size: 11; font-family: Verdana;">';
                $body .= '<tr><td>Name:</td><td>' . $name . '</td></tr>';
                $body .= '<tr><td>Email:</td><td>' . $email . '</td></tr>';
                $body .= '<tr><td>Mobile:</td><td>' . $mobile . '</td></tr>';
                $body .= '<tr><td>Source:</td><td>' . $source . '</td></tr>';
                $body .= $leadDetails;
                $body .= '</table>';
                $body .= '<br></br>';
                $body .= 'Regards';
                $body .= '<br></br>';
                $body .= $this->fromname;
                $body .= '<br></br>';
                $body .= '</body>';
                $body .= '</html>';
                $params['messageBody'] = $body;
                $params['subject'] = 'GFR  Price PopUp';

                // Send Mail
                if ($this->sendMail($params)) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        }  elseif ($source === 'Price PopUp') {

            if (EmailClass::validationCheckMobile($mobile) === true) {

                $body .= '<html>';
                $body .= '<body style="font-size: 11; font-family: Verdana;">';
                $body .= '<h3 style="color:#e91e63;"> Greetings from GFR , </h3>';
                $body .= '<p> Thank you for expressing interest on our website. Our expert will get in touch with you shortly. </p>';
                $body .= '<br/>';
                $body .= '<table style="font-size: 11; font-family: Verdana;">';
                $body .= '<tr><td>Name:</td><td>' . $name . '</td></tr>';
                $body .= '<tr><td>Email:</td><td>' . $email . '</td></tr>';
                $body .= '<tr><td>Mobile:</td><td>' . $mobile . '</td></tr>';
                $body .= '<tr><td>Source:</td><td>' . $source . '</td></tr>';
                $body .= $leadDetails;
                $body .= '</table>';
                $body .= '<br></br>';
                $body .= 'Regards';
                $body .= '<br></br>';
                $body .= $this->fromname;
                $body .= '<br></br>';
                $body .= '</body>';
                $body .= '</html>';
                $params['messageBody'] = $body;
                $params['subject'] = 'GFR  Price PopUp';

                // Send Mail
                if ($this->sendMail($params)) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } elseif ($source === 'Main PopUp') {

            if (EmailClass::validationCheckMobile($mobile) === true) {

                $body .= '<html>';
                $body .= '<body style="font-size: 11; font-family: Verdana;">';
                $body .= '<h3 style="color:#e91e63;"> Greetings from GFR , </h3>';
                $body .= '<p> Thank you for expressing interest on our website. Our expert will get in touch with you shortly. </p>';
                $body .= '<br/>';
                $body .= '<table style="font-size: 11; font-family: Verdana;">';
                $body .= '<tr><td>Name:</td><td>' . $name . '</td></tr>';
                //$body .= '<tr><td>Email:</td><td>' . $email . '</td></tr>';
                $body .= '<tr><td>Mobile:</td><td>' . $mobile . '</td></tr>';
                $body .= '<tr><td>Source:</td><td>' . $source . '</td></tr>';
                $body .= $leadDetails;
                $body .= '</table>';
                $body .= '<br></br>';
                $body .= 'Regards';
                $body .= '<br></br>';
                $body .= $this->fromname;
                $body .= '<br></br>';
                $body .= '</body>';
                $body .= '</html>';
                $params['messageBody'] = $body;
                $params['subject'] = 'GFR  Main PopUp';

                // Send Mail
                if ($this->sendMail($params)) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } elseif ($source === 'Check Availability') {

            if (EmailClass::validationCheckMobile($mobile) === true) {

                $body .= '<html>';
                $body .= '<body style="font-size: 11; font-family: Verdana;">';
                $body .= '<h3 style="color:#e91e63;"> Greetings from GFR , </h3>';
                $body .= '<p> Thank you for expressing interest on our website. Our expert will get in touch with you shortly. </p>';
                $body .= '<br/>';
                $body .= '<table style="font-size: 11; font-family: Verdana;">';
                $body .= '<tr><td>Name:</td><td>' . $name . '</td></tr>';
                $body .= '<tr><td>Email:</td><td>' . $email . '</td></tr>';
                $body .= '<tr><td>Mobile:</td><td>' . $mobile . '</td></tr>';
                $body .= '<tr><td>Source:</td><td>' . $source . '</td></tr>';
                $body .= $leadDetails;
                $body .= '</table>';
                $body .= '<br></br>';
                $body .= 'Regards';
                $body .= '<br></br>';
                $body .= $this->fromname;
                $body .= '<br></br>';
                $body .= '</body>';
                $body .= '</html>';
                $params['messageBody'] = $body;
                $params['subject'] = 'GFR  Download Brochure';

                // Send Mail
                if ($this->sendMail($params)) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } elseif ($source === 'Im Interested') {

            if (EmailClass::validationCheckMobile($mobile) === true) {

                $body .= '<html>';
                $body .= '<body style="font-size: 11; font-family: Verdana;">';
                $body .= '<h3 style="color:#e91e63;"> Greetings from GFR , </h3>';
                $body .= '<p> Thank you for expressing interest on our website. Our expert will get in touch with you shortly. </p>';
                $body .= '<br/>';
                $body .= '<table style="font-size: 11; font-family: Verdana;">';
                $body .= '<tr><td>Name:</td><td>' . $name . '</td></tr>';
                $body .= '<tr><td>Email:</td><td>' . $email . '</td></tr>';
                $body .= '<tr><td>Mobile:</td><td>' . $mobile . '</td></tr>';
                $body .= '<tr><td>Source:</td><td>' . $source . '</td></tr>';
                $body .= $leadDetails;
                $body .= '</table>';
                $body .= '<br></br>';
                $body .= 'Regards';
                $body .= '<br></br>';
                $body .= $this->fromname;
                $body .= '<br></br>';
                $body .= '</body>';
                $body .= '</html>';
                $params['messageBody'] = $body;
                $params['subject'] = 'GFR  Im Interested';

                // Send Mail
                if ($this->sendMail($params)) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } else {
            return false;
        }
    }

    public static function validationCheckMobile($mobile)
    {
        $msg = true;
        if (empty($mobile) || strlen($mobile) >= 18 || strlen($mobile) <= 3 || $mobile === 'Mobile:' || !(EmailClass::is_mobileNumber($mobile))) {
            $msg = 'Enter a valid mobile number';
            return $msg;
        }
        return $msg;
    }

    public static function validationCheckEmail($email)
    {
        $msg = true;
        if (empty($email) || !(EmailClass::isValidEmail($email)) || $email === 'Email:') {
            $msg = 'Enter a valid email address';
            return $msg;
        }
        return $msg;
    }

    public static function isValidEmail($email)
    {
        //return eregi("^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$", $email);
        return filter_var($email, FILTER_VALIDATE_EMAIL) && preg_match('/@.+\./', $email);
    }

    public static function is_mobileNumber($mobile)
    {
        $regex1 = '123456789';
        $regex2 = '1234567890';
        $regex3 = '0123456789';

        if (preg_match('/^([0-9])\1*$/', $mobile)) {
            return false;
        } elseif ($mobile == $regex1) {
            return false;
        } elseif ($mobile == $regex2) {
            return false;
        } elseif ($mobile == $regex3) {
            return false;
        } elseif (preg_match("/[^0-9]/", $mobile)) {
            return false;
        } else {
            return true;
        }
    }


    public function wadhwa_sfdc_api($name, $email, $mobile, $coutrycode, $campaign_code, $lead_id, $sfdc_project_interested)
    {

        if ($coutrycode == '+91' || $coutrycode == '91') {

            $phoneLen = strlen($mobile);

            $coutrycode = trim(str_replace('+', '', $coutrycode));
            $mobile = trim(str_replace('+', '', $mobile));
            if ($phoneLen > 10) {
                $mobile = substr($mobile, 2);
            }

        } else {
            $coutrycode = trim(str_replace('+', '', $coutrycode));

            $coutrycode_new = $coutrycode;
            $coutrycodelen = strlen($coutrycode_new);
            $coutrycodelen = $coutrycodelen + 2;
            //$coutrycode = '00'.$coutrycode;

            $coutrycode = trim((string)$coutrycode);
            $coutrycode = str_pad($coutrycode, $coutrycodelen, '00', STR_PAD_LEFT);

//            if($landing_page == 1){
//                $mobile = $coutrycode.$mobile;
//            }else{
//
//                $coutrycodelen = strlen($mobile);
//                $coutrycodelen = $coutrycodelen + 2;
//                $mobile = trim((string)$mobile);
//                $mobile = str_pad($mobile, $coutrycodelen, '00', STR_PAD_LEFT);
//            }

            $coutrycode = $coutrycode_new;
        }

        $sitevisitdate = '';

        $lead = new StdClass();
        $lead->mobileNumber = $mobile;
        $lead->countryCode = $coutrycode;
        $lead->dialingCode = $coutrycode;
        $lead->fullName = $name;
        $lead->emailAddress = $email;
        $lead->ProjectInterested = $sfdc_project_interested;
        $lead->OtherProjectInterested = $sfdc_project_interested;
        $lead->source = 'DIGITAL MARKETING';
        $lead->campaignCode = $campaign_code;
        $lead->channelCode = 'NA';
        $lead->description = 'NA';
        $lead->placement = 'NA';
        $lead->capturePoint = 'NA';
        $lead->pageURL = 'NA';
        $lead->searchKeyword = 'NA';
        $lead->sitevisitdate = $sitevisitdate;

        $leadData = array('wl' => $lead);
        /*echo '<pre>';
        print_r($leadData);*/

        $mySforceConnection = new SforcePartnerClient();
        $mySforceConnection->createConnection(__DIR__ . "/soapclient/partner.wsdl.xml");

        $mySforceConnection->setEndpoint('https://login.salesforce.com/services/Soap/u/35.0');

        $loginResult = $mySforceConnection->login(WADHWA_USERNAME, WADHWA_PASSWORD . WADHWA_SECURITY_TOKEN);

        $parsedURL = parse_url($mySforceConnection->getLocation());

        define("_SFDC_SERVER_", substr($parsedURL['host'], 0, strpos($parsedURL['host'], '.')));

        define("_WS_NAME_", 'WebToLeadServices');

        //define ("_WS_WSDL_", $_SERVER['DOCUMENT_ROOT'].'/sfdc_files/wadhwa/soapclient/WebToLeadServices.xml');

        define("_WS_WSDL_", __DIR__ . '/soapclient/WebToLeadServices_newxml.xml');

        define("_WS_ENDPOINT_", 'https://' . _SFDC_SERVER_ . '.salesforce.com/services/wsdl/class/' . _WS_NAME_);

        define("_WS_NAMESPACE_", 'http://soap.sforce.com/schemas/class/' . _WS_NAME_);

        $client = new SoapClient(_WS_WSDL_);

        $sforce_header = new SoapHeader(_WS_NAMESPACE_, "SessionHeader", array("sessionId" => $mySforceConnection->getSessionId()));

        $client->__setSoapHeaders(array($sforce_header));

        $response = $client->createLeadfromWeb($leadData);

        $response = get_object_vars($response);

        //print_r($response);

        //echo '---'.$response['result']->message;
        //exit;

//        $response_message = $response['result']->message;
//        $response_recordId = $response['result']->recordId;
//        $response_returnCode = $response['result']->returnCode;
//
//        if($response_message == '')
//        {
//            $response_message = 'CRM Message : Record not stored in SFDC';
//        }
//
//        $data = array('sfdc_message'=>$response_message,'sfdc_record_id'=>$response_recordId,'sfdc_return_code'=>$response_returnCode);
//        $this->db->where('leads_id',$response_recordId);
//        $this->db->update('tbl_leads', $data);

//        print_r($response);


    }

}

?>