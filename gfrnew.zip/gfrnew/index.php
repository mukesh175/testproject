<?php

// $cstm_ppc_placement = $_REQUEST['cstm_ppc_placement'];
// $cstm_ppc_keyword = $_REQUEST['cstm_ppc_keyword'];
// $cstm_ppc_device = $_REQUEST['cstm_ppc_device'];
// $cstm_ppc_campaign = $_REQUEST['cstm_ppc_campaign'];
// $cstm_ppc_channel = $_REQUEST['cstm_ppc_channel'];


// setcookie('cstm_ppc_placement', $cstm_ppc_placement, time() + (86400 * 180));
// setcookie('cstm_ppc_keyword', $cstm_ppc_keyword, time() + (86400 * 180));
// setcookie('cstm_ppc_device', $cstm_ppc_device, time() + (86400 * 180));
// setcookie('cstm_ppc_campaign', $cstm_ppc_campaign, time() + (86400 * 180));
// setcookie('cstm_ppc_channel', $cstm_ppc_channel, time() + (86400 * 180));



$keyword = $_REQUEST['cstm_ppc_keyword'];
$channel = $_REQUEST['cstm_ppc_channel'];
$campaign = $_REQUEST['cstm_ppc_campaign'];
$placement = $_REQUEST['cstm_ppc_placement'];
$device = $_REQUEST['cstm_ppc_device'];




if(isset($keyword))
{
    setcookie('cstm_ppc_keyword', $keyword, time() + (86400 * 180));
}


if(isset($channel))
{
    setcookie('cstm_ppc_channel', $channel, time() + (86400 * 180));
}


if(isset($campaign))
{
    setcookie('cstm_ppc_campaign', $campaign, time() + (86400 * 180));
}


if(isset($placement))
{
    setcookie('cstm_ppc_placement', $placement, time() + (86400 * 180));
}


if(isset($device))
{
    setcookie('cstm_ppc_device', $device, time() + (86400 * 180));
}




?>
<!DOCTYPE html>
<html>

<head>
    <!-- Google Tag Manager -->

    <!-- End Google Tag Manager -->


    <meta http-equiv="ContenType" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Online Nutrition Consultancy &mdash; Get Fit with Rihana </title>
    <meta name="keywords" content="">
    <meta name="">
    <link rel="icon" href="images/favicon.png" type="image/png" sizes="16x16">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"
        integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css" rel="stylesheet" type="text/css">
    <!--<link href="lightbox/lighbox.css" rel='stylesheet' type='text/css'>-->
    <link rel="stylesheet" href="css/hover.css">

    <link href="https://fonts.googleapis.com/css?family=Questrial&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/animate.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
    <script src="js/jquery-3.3.1.min.js"></script>

</head>

<body>
    <!-- Google Tag Manager (noscript) -->

    <!-- End Google Tag Manager (noscript) -->

    <header id="home">
        <nav class="navbar navbar-default" id="hide-menu">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="col-md-2">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                            data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="javascript:void(0)">
                            <img src="images/logo.png">
                          
                        </a>
                    </div>
                </div>

                <div class="col-md-10">
                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="#home" class="m-link">Home</a></li>
                            <li><a href="#gfr" class="m-link">About</a></li>
                            <li><a href="#realty" class="m-link">In The News</a></li>
                            <li><a href="#success" class="m-link">Success Stories</a></li>
                            <li><a href="#plan" class="m-link">Plans</a></li>
                            <li><a href="#testo" class="m-link">Testimonials</a></li>
                            <li><a href="#contactus" class="m-link">Contact Us</a></li>
               
                        </ul>
                    </div><!-- /.navbar-collapse -->
                </div><!-- /.container-fluid -->
               
            </div>
        </nav>
    </header>

    <div id="carousel-example-generic" class="carousel slide carousel-fade" data-ride="carousel">
        <ol class="carousel-indicators">
            <!-- <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li> -->
            <!-- <li data-target="#carousel-example-generic" data-slide-to="1" class=""></li> -->
            <!-- <li data-target="#carousel-example-generic" data-slide-to="2" class=""></li> -->
        </ol>
        <div class="carousel-inner" role="listbox">
            <div class="item active">
                <img src="images/slider/slide-1.jpg" alt="" class="hidden-xs">
                <img src="images/slider/mobile-1.jpg" alt="" class="visible-xs">
            </div>
         
        </div>
        <!-- <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
            <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
            <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a> -->
    </div>


    <section class="glob-sec" style="text-align: center;" id="gfr">
        <div class="container">
            <div class="col-md-6">
                <img src="images/overview.jpg" class="img-responsive" data-aos="fade-up" data-aos-delay="400"
                    data-aos-duration="1000" class="aos-init aos-animate">
            </div>
            <div class="col-md-6">
                <div class="presenting-wrap">
                    <h3 class="present aos-init aos-animate" data-aos="fade-up" data-aos-delay="600"
                        data-aos-duration="1000">About</h3>
                    <div class="head-line"></div>

                    <img class="o-logo aos-init aos-animate" src="images/logo.png" data-aos="fade-up"
                        data-aos-delay="600" data-aos-duration="1000">
                    <p>
                        Get Fit with Rihana (GFR) was born out of Rihana’s passion for fitness.
                    </p>
                    <p>
                        A certified sports nutritionist and a strength coach, Rihana believes, right nutrition and
                        training can do wonders for anyone.
                    </p>
                    <p>Her first stint was with an international gym chain as a personal trainer. Having trained some
                        primer clients there, she wanted to push the envelope and help anyone who was serious about
                        transforming themselves.</p>
                    <p>Rihana’s mission is to use her experience and knowledge to change people’s views and
                        misconceptions about food, body, and weightlifting. She helps people accomplish their weight
                        loss goals by not only providing exercise and diet plans but also huge doses of motivation
                        throughout their weight loss journey.</p>
                    <p>GFR is a sincere effort to transform not just health but lives.</p>

                    <h4>GET FIT WITH RAHANA<br>Nutrition | Training</h4>
                </div>
            </div>
        </div>
    </section>
    <section id="realty" class="section-row">
        <div class="container">
            <h3 class="text-center present aos-init aos-animate" data-aos="fade-up" data-aos-delay="600"
                data-aos-duration="1000">In The News</h3>
            <div class="head-line"></div>

            <div class="col-md-4">
                <div class="prop-div">

                    <a class="move" onclick="pricePopProjectname('');">
                        <div class="prop-img-div">
                            <img src="images/news1.jpeg" class="full-width">
                           
                        </div>
                    </a>
                    <div class="prop-details">

                        <div class="prop-innerhead">
                            <p class="sub-head">
                                NUTRITIONIST RIHANA QURESHI GIVES A NEW MEANING TO THE FOOD WE EAT; READ DETAILS
                            </p>

                        </div>
                        <div class="prop-inner">
                            <p class="prop-conf">
                                The world of fitness has predominantly been termed as a man's world. If one steps inside
                                any gym, it is seldom that one will see a woman fitness trainer, so it is not hard to
                                imagine what a complete newbie like Rihana Qureshi, must have faced when she entered the
                                profession a few years back.
                            </p>

                        </div>
                    </div>
                    <div class="prop-tour">

                        <a href="https://m.republicworld.com/lifestyle/health/nutritionist-rihana-qureshi-gives-a-new-meaning-to-the-food-we-eat.html" target="_blank">
                            <div class="col-xs-10">

                                <div class="tour">
                                    READ MORE</div>
                            </div>

                            <div class="col-xs-2 pd0">
                                <div class="button-tour" id="button-2">
                                    <div id="slide">

                                    </div>
                                    <i class="fa fa-arrow-right" aria-hidden="true"></i>
                                </div>
                            </div>
                        </a>
                    </div>


                </div>

            </div>


            <div class="col-md-4">
                <div class="prop-div">

                    <a class="move" onclick="pricePopProjectname('');">
                        <div class="prop-img-div">
                            <img src="images/news1.jpeg" class="full-width">
                            <!-- <p class="offer-patch">
                                Actual Site
                                Photo</p> -->
                        </div>
                    </a>
                    <div class="prop-details">

                        <div class="prop-innerhead">
                            <p class="sub-head">
                                NUTRITIONIST RIHANA QURESHI GIVES A NEW MEANING TO THE FOOD WE EAT; READ DETAILS
                            </p>

                        </div>
                        <div class="prop-inner">
                            <p class="prop-conf">
                                The world of fitness has predominantly been termed as a man's world. If one steps inside
                                any gym, it is seldom that one will see a woman fitness trainer, so it is not hard to
                                imagine what a complete newbie like Rihana Qureshi, must have faced when she entered the
                                profession a few years back.
                            </p>

                        </div>
                    </div>
                    <div class="prop-tour">

                        <a href="https://m.republicworld.com/lifestyle/health/nutritionist-rihana-qureshi-gives-a-new-meaning-to-the-food-we-eat.html" target="_blank">
                            <div class="col-xs-10">

                                <div class="tour">
                                    READ MORE</div>
                            </div>

                            <div class="col-xs-2 pd0">
                                <div class="button-tour" id="button-2">
                                    <div id="slide">

                                    </div>
                                    <i class="fa fa-arrow-right" aria-hidden="true"></i>
                                </div>
                            </div>
                        </a>
                    </div>


                </div>

            </div>



            <div class="col-md-4">
                <div class="prop-div">

                    <a class="move" onclick="pricePopProjectname('');">
                        <div class="prop-img-div">
                            <img src="images/news1.jpeg" class="full-width">
                            <!-- <p class="offer-patch">
                                Actual Site
                                Photo</p> -->
                        </div>
                    </a>
                    <div class="prop-details">

                        <div class="prop-innerhead">
                            <p class="sub-head">
                                NUTRITIONIST RIHANA QURESHI GIVES A NEW MEANING TO THE FOOD WE EAT; READ DETAILS
                            </p>

                        </div>
                        <div class="prop-inner">
                            <p class="prop-conf">
                                The world of fitness has predominantly been termed as a man's world. If one steps inside
                                any gym, it is seldom that one will see a woman fitness trainer, so it is not hard to
                                imagine what a complete newbie like Rihana Qureshi, must have faced when she entered the
                                profession a few years back.
                            </p>

                        </div>
                    </div>
                    <div class="prop-tour">

                        <a href="https://m.republicworld.com/lifestyle/health/nutritionist-rihana-qureshi-gives-a-new-meaning-to-the-food-we-eat.html" target="_blank">
                            <div class="col-xs-10">

                                <div class="tour">
                                    READ MORE</div>
                            </div>

                            <div class="col-xs-2 pd0">
                                <div class="button-tour" id="button-2">
                                    <div id="slide">

                                    </div>
                                    <i class="fa fa-arrow-right" aria-hidden="true"></i>
                                </div>
                            </div>
                        </a>
                    </div>


                </div>

            </div>


        </div>



    </section>

    <section class="glob-sec" id="success">
        <div class="container">
            <h3 class="text-center present aos-init aos-animate" data-aos="fade-up" data-aos-delay="600"
                data-aos-duration="1000">Success Stories</h3>
            <div class="head-line"></div>

            <div style="width: 100%;height: 20px;"></div>

            <div class="tab-rwap">
                <ul class="nav nav-tabs mytab" role="tablist">
                    <!-- <li role="presentation" class="active">
                        <a href="#general" aria-controls="profile" role="tab" data-toggle="tab"
                            aria-expanded="true">General
                        </a>
                    </li>
                    <li role="presentation" class="">
                        <a href="#interior" aria-controls="settings" role="tab" data-toggle="tab"
                            aria-expanded="false">Interior
                        </a>
                    </li> -->
                    <!-- <li role="presentation" class="">
                        <a href="#floorplan" aria-controls="settings" role="tab" data-toggle="tab"
                            aria-expanded="false">Floor Plan
                        </a>
                    </li> -->
                    <!-- <li role="presentation" class="">
                    <a href="#loc" aria-controls="settings" role="tab" data-toggle="tab" aria-expanded="false">
                        Location
                    </a>
                </li> -->

                </ul>
                <div class="tab-content" style="visibility: visible; animation-name: fadeInDown;">
                    <div role="tabpanel" class="tab-pane fade active in" id="general">
                        <div class="tab-contenwrap">

                            <div class="col-md-4 pd0">

                                <div class="amenities-gallery mg-mb box">
                                    <div class="box">
                                        <a data-fancybox="general" href="images/gallery/general/1.jpeg" class="l-box">

                                            <img src="images/gallery/general/1.jpeg">
                                            <div class="box-content">

                                            </div>
                                        </a>
                                    </div>

                                </div>


                            </div>
                            <div class="col-md-4 pd0">
                                <div class="amenities-gallery mg-mb box">
                                    <div class="box">
                                        <a data-fancybox="general" href="images/gallery/general/2.jpeg" class="l-box">

                                            <img src="images/gallery/general/2.jpeg">
                                            <div class="box-content">

                                            </div>
                                        </a>
                                    </div>

                                </div>
                            </div>
                            <div class="col-md-4 pd0">
                                <div class="amenities-gallery mg-mb box">
                                    <div class="box">
                                        <a data-fancybox="general" href="images/gallery/general/3.jpeg" class="l-box">

                                            <img src="images/gallery/general/3.jpeg">
                                            <div class="box-content">

                                            </div>
                                        </a>
                                    </div>

                                </div>
                            </div>




                        </div>
                    </div>


                </div>
            </div>
        </div>
    </section>

    <section id="plan" class="section-row">
        <div class="container">
            <h3 class="text-center present aos-init aos-animate" data-aos="fade-up" data-aos-delay="600"
                data-aos-duration="1000">Plans</h3>
            <div class="head-line"></div>
            <div style="width: 100%;height: 20px;"></div>

            <div class="">
                <div class="w3_agile_team_grids">
                    <div class="col-md-4 w3_agile_team_grid">
                        <div class="hover14 column">
                            <div class="">
                                <div class="pricingTable">
                                    <div class="pricingTable-header">
                                        <h3 class="title">3 month Nutrition<br>
                                            Plan</h3>
                                    </div>
                                    <ul class="pricing-content">
                                        <li>3 month nutrition
                                            plan</li>
                                        <li>50 Email Accounts</li>
                                        <li>Customized to your
                                            lifestyle preferences</li>
                                        <li class="">1 st consultation with
                                            Rihana
                                            No follow-up
                                            consultations</li>
                                        <li class="">Whatsapp/Call
                                            Support by the team</li>
                                        <li class="disable">*</li>

                                    </ul>
                                    <div class="price-value">
                                        <span class="price-title">Price <b>From</b></span>
                                        <span class="price-amount"> <del>Rs.15,000</del>
                                            Rs.10,000 <span class="duration"></span></span>
                                    </div>
                                    <div class="pricingTable-signup">
                                        <a href="https://pages.razorpay.com/pl_DRZc42fBbijAmw/view" target="_blank">Sign Up</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-4 w3_agile_team_grid">
                        <div class="hover14 column">
                            <div class="">
                                <div class="pricingTable">
                                    <div class="pricingTable-header">
                                        <h3 class="title">3 Month Personal
                                            Nutrition
                                            Consultation</h3>
                                    </div>
                                    <ul class="pricing-content">
                                        <li>3 month nutrition
                                            plan</li>
                                        <li>Customized to your
                                            lifestyle preferences</li>
                                        <li>Daily guidance and
                                            follow-up by Rihana</li>
                                        <li class="">Direct
                                            Call/Whatsapp
                                            support by Rihana</li>
                                        <li class="disable">*</li>
                                    </ul>
                                    <div class="price-value">
                                        <span class="price-title">Price <b>From</b></span>
                                        <span class="price-amount"><del>Rs.40,000</del>
                                            Rs.30,0000</span></span>
                                    </div>
                                    <div class="pricingTable-signup">
                                        <a href="https://pages.razorpay.com/pl_DRZjy3z235n9nc/view" target="_blank">Sign Up</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-4 w3_agile_team_grid">
                        <div class="hover14 column">
                            <div class="">
                                <div class="pricingTable">
                                    <div class="pricingTable-header">
                                        <h3 class="title">Online Training + 3
                                            Month Personal
                                            Nutrition
                                            Consultation</h3>
                                    </div>
                                    <ul class="pricing-content">
                                        <li>3 month nutrition
                                            plan</li>
                                        <li>Customized to your
                                            lifestyle preferences</li>
                                        <li>Daily guidance and
                                            follow-up by Rihana</li>
                                        <li class="">Direct
                                            Call/Whatsapp
                                            support by Rihana</li>
                                        <li class="">30 online training
                                            sessions by Rihana</li>
                                    </ul>
                                    <div class="price-value">
                                        <span class="price-title">Price <b>From</b></span>
                                        <span class="price-amount"> On <span class="duration">Request</span></span>
                                    </div>
                                    <div class="pricingTable-signup">
                                        <a class="download1" href="javascript:void(0);">Check Availability</a>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                    <div class="clearfix"> </div>
                </div>
            </div>


        </div>



    </section>



    <section class="glob-sec" id="testo">
        <div class="container">
            <h3 class="text-center present aos-init aos-animate" data-aos="fade-up" data-aos-delay="600"
                data-aos-duration="1000">Testimonials</h3>
            <div class="head-line"></div>
            <div style="width: 100%;height: 20px;"></div>

            <div class="row">
                <div class="col-md-12">
                    <div id="testimonial-slider" class="owl-carousel testimonial-slider">
                        <div class="testimonial">
                            <div class="pic">
                                <img src="images/img-2.jpg">
                            </div>
                            <p class="description">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto commodi dolorum
                                earum fugiat, fugit hic id, ipsum laborum minus nostrum numquam perspiciatis saepe
                                velit.
                            </p>
                            <div class="testimonial-profile">
                                <h3 class="title"></h3>
                                <span class="post"></span>
                            </div>
                        </div>

                        <div class="testimonial">
                            <div class="pic">
                                <img src="images/img-2.jpg">
                            </div>
                            <p class="description">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto commodi dolorum
                                earum fugiat, fugit hic id, ipsum laborum minus nostrum numquam perspiciatis saepe
                                velit.
                            </p>
                            <div class="testimonial-profile">
                                <h3 class="title"></h3>
                                <span class="post"></span>
                            </div>
                        </div>

                        <div class="testimonial">
                            <div class="pic">
                                <img src="images/img-2.jpg">
                            </div>
                            <p class="description">
                                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto commodi dolorum
                                earum fugiat, fugit hic id, ipsum laborum minus nostrum numquam perspiciatis saepe
                                velit.
                            </p>
                            <div class="testimonial-profile">
                                <h3 class="title"></h3>
                                <span class="post"></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>






    <!--<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15079.416113664794!2d72.82416112305296!3d19.1140586331899!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c9c34e1585bb%3A0x8ce4216e331c5189!2sJuhu+Vikrant+Building!5e0!3m2!1sen!2sin!4v1539783378101"
width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>-->

    <section class="glob-sec-bg light-grey" id="contactus">

        <div class="overlay">
            <div class="container">
                <!-- <img class="head-icon wow fadeInUp" data-wow-duration="1s" data-wow-delay="1s"
         src="images/head-icon-white.png"> -->
                <h2 class="sec-head head-center white wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.5s">Contact
                    Us</h2>
                <div class="head-line"></div>
                <!--<div style="width: 100%;height: 25px;"></div>-->
                <div class="col-md-12">
                    <div class="form-wrap">
                        <h1>Please enter the details below to get in touch with us!</h1>
                        <form id="contact-form" action="thank-you.php" name="contact-form" method="POST"
                            onsubmit="return save_landing_pageinfo('contact-form');" novalidate="novalidate">

                            <div class="form-group col-md-3">
                                <div class="input-group">

                                    <input type="text" class="form-control" name="fname" placeholder=" Name">
                                </div>
                                <label for="fname" generated="true" class="error"></label>
                            </div>

                            <!-- <div class="form-group col-md-3">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-user form-ico" aria-hidden="true"></i>
                                    </div>
                                    <input type="text" class="form-control" name="lname" placeholder="Last Name">
                                </div>
                                <label for="lname" generated="true" class="error"></label>
                            </div> -->

                            <div class="form-group col-md-3">
                                <div class="input-group">

                                    <input type="number" class="form-control" name="mobile" placeholder="Mobile">
                                </div>
                                <label for="mobile" generated="true" class="error"></label>
                            </div>
                            <div class="form-group col-md-3">
                                <div class="input-group">

                                    <input type="email" class="form-control" name="email" placeholder="Email">
                                    <input type="hidden" name="source" value="Enquiry Form">
                                </div>
                                <label for="email" generated="true" class="error"></label>
                            </div>


                            <button type="submit" class="btn btn-default form-btn hvr-sweep-to-right">Submit
                            </button>
                        </form>
                    </div>
                    <!-- <div class="callup">
                        <p>Enquire About The Project</p>
                        <span id="contactNumber">
                            <span id="waybeo_num" style="visibility:hidden">022 6144 6631</span>
                        </span>
                    </div> -->

                </div>
            </div>
        </div>
    </section>

    <section class="footer-sec" id="footer">
        <div class="container">
            <div class="foote-wrap">
                <img src="images/logo.png">
                <!--<img class="head-icon" src="images/head-icon.png">-->

                <div class="contacwrap">
                    <p>
                        For any inquiries, questions, or to register your interest, please contact us using the details
                        below
                    </p>

                    <!-- <ul class="address">
                        <li><i class="fas fa-phone"></i> 022 6144 6641</li>
                        <li><i class="fas fa-building"></i>GFR, Goregaon Mulund Link
                            Road, Near Fortis Hospital, Mulund (West), Mumbai - 400 080
                        </li>
                    </ul> -->
                    <ul class="reralist">
                        <li><img class="whatsapp" src="images/whatsapp.png" style="">&nbsp; <a href="tel:+919321490890"
                                class="fix-link"><b>+919321490890</b></li>

                    </ul>

                    <div class="address-line"></div>


                    <!-- <div style="width: 100%;height: 30px;"></div> -->

                    <ul class="partner">
                        <li><a href="https://www.instagram.com/getfitwithrihana/" target="_blank"> <img
                                    src="images/linkedin.png"></a></li>
                        <li><a href="https://www.facebook.com/getfitwithrihana" target="_blank"><img
                                    src="images/facebook.png" class=""></a></li>
                        <li><a href="https://www.youtube.com/channel/UCFB67EsuhivAYAdDpyl_V8Q/featured"
                                target="_blank"><img src="images/youtube.png" class=""></a></li>

                    </ul>

                    <div style="width: 100%;height: 30px;"></div>

                    <p class="copy-right">© GFR All Rights Reserved 2020.</p>

                </div>

            </div>
        </div>
    </section>
    <section class="rera-sec">
        <div class="container">
            <h3>Disclaimer</h3>
            <p>
                The plans and services mentioned here are non-refundable. By making a purchase on this
                page, you agree to the terms and conditions of this page.</p>
            <p style="margin-top: 0;">

                <a class="disc-btn" href="privacy.php">Privacy Policy</a>
            </p>

        </div>
    </section>


    <div class="col-lg-12 col-sm-12 col-xs-12 fixed-footer-cust hidden-md hidden-lg hidden-sm">
        <div class="container">
            <div class="col-lg-6 col-sm-6 col-xs-6 div-line pd0">
                <a href="tel:+919321490890" class="fix-link"><i class="fa fa-phone f-icon" aria-hidden="true"></i> CALL
                    NOW</a>
            </div>
            <div class="col-lg-6 col-sm-6 col-xs-6 pd0">
                <a type="button" class="fix-link i-am"><i class="fa fa-pencil-square-o f-icon" aria-hidden="true"></i>
                    ENQUIRE</a>
            </div>
        </div>
    </div>



    <div id="pageloader">
        <img src="images/loading.gif" alt="processing..." />
    </div>

    <!-- ================ main popup ==================== -->

    <div class="modal fade in" tabindex="-1" role="dialog" id="main-pop" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">×</span></button>

                    <h4 class="modal-title">Enquire Now</h4>
                </div>
                <div class="modal-body">
                    <!-- <p>phere O2 </p> -->
                    <form id="main-popup" action="thank-you.php" name="main-popup" method="POST" novalidate="novalidate"
                        onsubmit="return save_landing_pageinfo('main-popup');">
                        <div class="form-group col-md-12">
                            <div class="input-group">

                                <input type="text" class="form-control" name="fname" placeholder="Name">
                                <input type="hidden" name="source" value="Main PopUp">
                            </div>
                            <label for="fname" generated="true" class="error"></label>
                        </div>
                        <div class="form-group col-md-12">
                            <div class="input-group">

                                <input type="number" class="form-control" name="mobile" placeholder="Mobile">
                            </div>
                            <label for="mobile" generated="true" class="error"></label>
                        </div>
                        <div class="form-group col-md-12">
                            <div class="input-group">

                                <input type="email" class="form-control" name="email" placeholder="Email">
                            </div>
                            <label for="email" generated="true" class="error"></label>
                        </div>

                        <button type="submit" class="btn btn-default price-btn hvr-sweep-to-right">SUBMIT</button>
                    </form>


                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>

    <!-- ============================================= -->


    <!-- ================ price popup ==================== -->


    <div class="modal fade in" tabindex="-1" role="dialog" id="price-model" data-backdrop="static"
        data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">×</span></button>

                    <h4 class="modal-title">Pricing Information</h4>
                </div>
                <div class="modal-body">
                    <!-- <p>Please Enter Your Details To Get Pricing Information</p> -->
                    <form id="price-popup" action="thank-you.php" name="price-popup" method="POST"
                        novalidate="novalidate" onsubmit="return save_landing_pageinfo('price-popup');">
                        <div class="form-group col-md-12">
                            <div class="input-group">

                                <input type="text" class="form-control" name="fname" placeholder="Name">
                                <input type="hidden" name="source" value="Price PopUp">
                            </div>
                            <label for="fname" generated="true" class="error"></label>
                        </div>
                        <div class="form-group col-md-12">
                            <div class="input-group">

                                <input type="number" class="form-control" name="mobile" placeholder="Mobile">
                            </div>
                            <label for="mobile" generated="true" class="error"></label>
                        </div>
                        <div class="form-group col-md-12">
                            <div class="input-group">

                                <input type="email" class="form-control" name="email" placeholder="Email">
                            </div>
                            <label for="email" generated="true" class="error"></label>
                        </div>

                        <button type="submit" class="btn btn-default price-btn hvr-sweep-to-right">SUBMIT</button>
                    </form>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>

    <!-- ============================================= -->

    <button class="btn btn-danger interested hidden-xs">Enquire Now</button>
    <!-- <button class="btn btn-danger download1 btn-download hidden-xs">Download Brochure</button> -->
    <!-- ================ i am ==================== -->
    <div class="modal fade in" tabindex="-1" role="dialog" id="interested" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                    <h4 class="modal-title">Enquire Now</h4>
                </div>
                <div class="modal-body">
                    <!-- <p>phere O2 </p> -->
                    <form id="float-form" action="thank-you.php" name="price-popup" method="POST"
                        novalidate="novalidate" onsubmit="return save_landing_pageinfo('float-form');">
                        <div class="form-group col-md-12">
                            <div class="input-group">

                                <input type="text" class="form-control" name="fname" placeholder="Name">
                                <input type="hidden" name="source" value="Im Interested">
                            </div>
                            <label for="fname" generated="true" class="error"></label>
                        </div>
                        <div class="form-group col-md-12">
                            <div class="input-group">

                                <input type="number" class="form-control" name="mobile" placeholder="Mobile">
                            </div>
                            <label for="mobile" generated="true" class="error"></label>
                        </div>

                        <div class="form-group col-md-12">
                            <div class="input-group">

                                <input type="email" class="form-control" name="email" placeholder="Email">
                            </div>
                            <label for="email" generated="true" class="error"></label>
                        </div>

                        <button type="submit" class="btn btn-default price-btn hvr-sweep-to-right">SUBMIT</button>
                    </form>

                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>

    <!-- ============================================= -->

    <div class="modal fade in" tabindex="-1" role="dialog" id="download1" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Check Availability</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">×</span></button>


                </div>
                <div class="modal-body">
                    <!-- <p>Please enter the details below to download brochure.</p> -->
                    <form id="download-brochure" action="thank-you.php" name="download-brochure" method="POST"
                        onsubmit="return save_landing_pageinfo('download-brochure');">
                        <div class="form-group col-md-12 pd">
                            <div class="input-group">

                                <input type="text" class="form-control" name="fname" placeholder="Name">
                                <input type="hidden" name="source" value="Check Availability" id="source">
                            </div>
                            <label for="fname" generated="true" class="error"></label>
                        </div>
                        <div class="form-group col-md-12 pd">
                            <div class="input-group">

                                <input type="number" class="form-control" placeholder="Phone*" name="mobile" required>
                            </div>
                            <label for="mobile" generated="true" class="error"></label>
                        </div>

                        <div class="form-group col-md-12 pd">
                            <div class="input-group">

                                <input type="email" class="form-control" name="email" placeholder="Email">
                                <input type="hidden" name="country_code" value="" id="calling_code">
                            </div>
                            <label for="email" generated="true" class="error"></label>
                        </div>




                        <button type="submit" class="btn btn-default price-btn" value="proceed">SUBMIT</button>
                    </form>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div>



    <!-- -======================  Disclaimer PopUp  -->


    <div class="modal fade in" tabindex="-1" role="dialog" id="floorplan" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Download Floor Plan</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">×</span></button>


                </div>
                <div class="modal-body">
                    <p>Please enter the details below to download Floor Plan.</p>
                    <form id="floor" action="thank-you.php" name="floor" method="POST"
                        onsubmit="return save_landing_pageinfo('floor');">
                        <div class="form-group col-md-12 pd">
                            <div class="input-group">

                                <input type="text" class="form-control" name="fname" placeholder="Name">
                                <input type="hidden" name="source" value="Floor Plan" id="source">
                            </div>
                            <label for="fname" generated="true" class="error"></label>
                        </div>
                        <div class="form-group col-md-12 pd">
                            <div class="input-group">

                                <input type="number" class="form-control" placeholder="Phone*" name="mobile" required>
                            </div>
                            <label for="mobile" generated="true" class="error"></label>
                        </div>

                        <div class="form-group col-md-12 pd">
                            <div class="input-group">

                                <input type="email" class="form-control" name="email" placeholder="Email">
                                <input type="hidden" name="country_code" value="" id="calling_code">
                            </div>
                            <label for="email" generated="true" class="error"></label>
                        </div>




                        <button type="submit" class="btn btn-default price-btn" value="proceed">SUBMIT</button>
                    </form>
                </div>
            </div>
        </div>
    </div>






    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/cookie.js"></script>


    <script src="js/jquery.validate.js"></script>
    <script src="js/mobilevalidate.js"></script>

    <script src="js/popout.js"></script>

    <script src="https://cdn.jsdelivr.net/gh/fancyapps/fancybox@3.5.7/dist/jquery.fancybox.min.js"></script>

    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js">
    </script>



    <script>
    jQuery(document).ready(function($) {
        $('[data-fancybox="general"]').fancybox({

            //slide effec zoom-in-out
            transitionEffect: "slide",
            loop: false,

            buttons: [
                //'slideShow',
                //'share',
                'zoom',
                'fullScreen',
                'close'
                //'download'
            ],
            thumbs: {
                autoStart: false
            }
        });
        $('[data-fancybox="interior"]').fancybox({

            //slide effec zoom-in-out
            transitionEffect: "slide",
            loop: false,

            buttons: [
                //'slideShow',
                //'share',
                'zoom',
                'fullScreen',
                'close'
                //'download'
            ],
            thumbs: {
                autoStart: false
            }
        });
        $('[data-fancybox="floorplan"]').fancybox({

            //slide effec zoom-in-out
            transitionEffect: "slide",
            loop: false,

            buttons: [
                //'slideShow',
                //'share',
                'zoom',
                'fullScreen',
                'close'
                //'download'
            ],
            thumbs: {
                autoStart: false
            }
        });
        $('[data-fancybox="masterplan"]').fancybox({

            //slide effec zoom-in-out
            transitionEffect: "slide",
            loop: false,

            buttons: [
                //'slideShow',
                //'share',
                'zoom',
                'fullScreen',
                'close'
                //'download'
            ],
            thumbs: {
                autoStart: false
            }
        });
    });
    </script>



    <script type="text/javascript">
    jQuery(document).ready(function($) {
        Delete_Cookie('formfilled');





        // ---------------for model only-----
        $(".price-click").click(function() {
            $('#price-model').modal('show');
        });

        $(".interested").click(function() {
            $('#interested').modal('show');
        });

        $(".i-am").click(function() {
            $('#interested').modal('show');
        });

        $(".maplink").click(function() {
            $('#gmap').modal('show');
        });

        $(".download1").click(function() {
            $('#download1').modal('show');
        });

        $(".floor").click(function() {
            $('#floorplan').modal('show');
        });


    });
    </script>

    <script>
    $(document).ready(function() {
        $("#testimonial-slider").owlCarousel({
            items: 2,
            itemsDesktop: [1000, 2],
            itemsDesktopSmall: [979, 2],
            itemsTablet: [768, 2],
            itemsMobile: [650, 1],
            pagination: true,
            navigation: false,
            slideSpeed: 1000,
            autoPlay: true
        });
    });
    </script>


    <script>
    jQuery(document).ready(function($) {
        // Add smooth scrolling to all links
        $(".m-link").on('click', function(event) {

            // Make sure this.hash has a value before overriding default behavior
            if (this.hash !== "") {
                // Prevent default anchor click behavior
                event.preventDefault();

                // Store hash
                var hash = this.hash;

                // Using jQuery's animate() method to add smooth page scroll
                // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area

                $('html, body').animate({
                    scrollTop: $(hash).offset().top
                }, 800, function() {
                    // Add hash (#) to URL when done scrolling (default click behavior)
                    // window.location.hash = hash;
                });
            } // End if
        });

        $('.navbar-nav li').on('click', function() {
            $('.navbar-nav li.active').removeClass('active');
            $(this).addClass('active');
        });
        $(document).on('click', '.navbar-collapse.in', function(e) {
            if ($(e.target).is('a') && ($(e.target).attr('class') != 'dropdown-toggle')) {
                $(this).collapse('hide');
            }
        });
    });
    </script>

    <script>
    $(window).scroll(function() {
        var scroll = $(window).scrollTop();

        if (scroll >= 75) {
            $("#hide-menu").addClass("fixHeader");
        } else {
            $("#hide-menu").removeClass("fixHeader");
        }
    });
    </script>


    <script type="text/javascript">
    function save_landing_pageinfo(elm) {
        jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', true);
        setTimeout(function() {
            jQuery('#' + elm + ' input[type=submit], #' + elm + ' button').prop('disabled', false);
        }, 5000);
        var name = jQuery('#' + elm + ' input[name="fname"]').val();
        var mobileno = jQuery('#' + elm + ' input[name="mobile"]').val();
        var emailid = jQuery('#' + elm + ' input[name="email"]').val();
        var message = jQuery('#' + elm + ' textarea[name="message"]').val();
        var fsource = jQuery('#' + elm + ' input[name="source"]').val();
        var current_url = location.hostname;

        if (name == "") {
            //alert("Please Enter Your Name");
            return false;
        }

        mobileno = mobileno.replace(/[^0-9]/g, '');
        if (mobileno.length != 10) {
            //alert("Please Enter 10 Digit Mobile Number");
            return false;
        }

        if (elm == 'price-popup') {
            emailid = "";
        } else if (elm == 'main-popup') {
            emailid = "";
        } else {
            var atpos = emailid.indexOf("@");
            var dotpos = emailid.lastIndexOf(".");
            if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= emailid.length) {
                return false;
            }
        }

        if (message == undefined) {
            message = "";
        }




        var _phone = mobileno;

        if (name != "" && mobileno != "") {
            $("#pageloader").fadeIn();
            // makecallNormal(_phone);
            var tags = 'GFR ';
            var webToLeadData = {
                'firstname': name,
                'email': emailid,
                'mobile': mobileno,
                'tags': tags,
                'cstm_fsource': fsource,
                'cstm_current_url': current_url
            };


            MTI.webToLead(webToLeadData,
                function() {
                    submitForm(elm);
                },
                function(respone) {
                    console.log(respone);
                    submitForm(elm);
                }
            );
        }




        return false;
    }

    function submitForm(elm) {
        document.createElement('form').submit.call(document.getElementById(elm));
    }
    </script>





</body>

</html>