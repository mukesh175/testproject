<?php
$name = $_REQUEST['fname'];
$mobile = $_REQUEST['mobile'];


$mobile = $_REQUEST['mobile'];
$message = $_REQUEST['message'];
if(!empty($message))
{
    die;
} 
if(ctype_alpha(str_replace(' ', '', $name)) === false)
    {
      die;
    }

if(!preg_match('/^[0-9]+$/', $_POST['mobile']))
    {
      die;
    }

if(empty($name))
{
    die;
} 

    if(empty($mobile))
{
    die;
} 
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

session_start();
require_once 'class/emailClass.php';

/*require_once 'gcaptcha.php';
$source = $_REQUEST['source'];
if($source === 'Enquiry Form'){

    $reCaptcha = new reCaptcha();
    $reCaptcha = $reCaptcha->verifyReCaptcha();

    if (isset($reCaptcha) && isset($reCaptcha->success) && !$reCaptcha->success) {
        echo 'Please fill the Google reCaptcha correctly';
        return;
    }
}*/
$emailClass = new EmailClass();
if ((!isset($_COOKIE['formfilled'])) && isset($_REQUEST['mobile'])) {
    $mailsent = $emailClass->callback();
    setcookie('formfilled', 'yes');
} else {
    $mailsent = false;
}
?>
<!DOCTYPE html>
<html>

<head>
   


  
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>GFR | Thank You</title>
    <meta name="keywords" content="">
    <meta name="">
    <link rel="icon" href="images/favicon.png" type="image/png" sizes="16x16">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css"
        integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">

    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="css/bootstrap-theme.min.css" rel="stylesheet" type="text/css">
    <link href="css/style.css?v=1.0" rel="stylesheet" type="text/css">
    <link href="lightbox/light-box.css" rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/animate.min.css">
</head>

<body>
   

    <header id="home">
        <nav class="navbar navbar-default thank-menu" id="hide-menu">
            <div class="container">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"
                        data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="javascript:void(0)">
                        <img src="images/logo.png">
                    </a>
                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

                    <ul class="nav navbar-nav navbar-right">
                        

                        <li><a href="index.php" class="m-link">Home</a></li>
                            <li><a href="index.php" class="m-link">About</a></li>
                            <li><a href="index.php" class="m-link">In The News</a></li>
                            <li><a href="index.php" class="m-link">Success Stories</a></li>
                            <li><a href="index.php" class="m-link">Plans</a></li>
                            <li><a href="index.php" class="m-link">Testimonials</a></li>
                            <li><a href="index.php" class="m-link">Contact Us</a></li>
                       
                    </ul>
                </div><!-- /.navbar-collapse -->
            </div><!-- /.container-fluid -->
        </nav>
    </header>

    <section class="inner-banner">
        <div class="container">
            <div class="banner-txt-thank">
                <h1><span>Thank</span> You!</h1>
            </div>
        </div>
    </section>


    <section class="glob-sec">
        <div class="container">
            <div class="wrap" style="padding:15px;height:auto !important;">


                <?php
            if (!$mailsent) {
                ?>

                <span class="msgicon" aria-hidden="true"><i class="fa fa-times" aria-hidden="true"></i></span>
                <h2 class="oops">Oops!</h2>
                <h3 class="oops-subtitle" style="text-align:center;">
                    Sorry for the inconvenience! Mail could not be sent.<br />
                    Please try again after some time.
                </h3>

                <!--<div class="social-wrap">
                    <p>Meanwhile, follow us on</p>

                    <ul class="social-icon">
                        <li>
                            <a href="https://www.facebook.com/JewelCrestbyJewelGroup/?utm_source=DigitalAds&utm_campaign=ThankyouPage" target="_blank">
                                <img src="images/facebook.png">
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/jewelcrest/?utm_source=DigitalAds&utm_campaign=ThankyouPage" target="_blank">
                                <img src="images/instagram.png">
                            </a>
                        </li>
                        <li>
                            <a href="https://www.facebook.com/JewelCrestbyJewelGroup/?utm_source=DigitalAds&utm_campaign=ThankyouPage" target="_blank">
                                <img src="images/linkedin.png">
                            </a>
                        </li>
                    </ul>
                </div>-->

                <a href="index.php" style="text-decoration: none;">
                    <!-- <h2 class="go-home">
                        <span class="" aria-hidden="true">
                            <i class="fa fa-arrow-left" aria-hidden="true"></i>
                        </span> 
                    </h2> -->
                </a>
                <?php
            } else {
                ?>
                <span class="msgicon" aria-hidden="true"><i class="fa fa-check" aria-hidden="true"></i></span>
                <h2 class="oops"><span>You're</span> All Set!</h2>
                <h3 class="oops-greet" style="text-align:center;">Greetings from Wadhwa Group</h3>
                <h3 class="oops-subtitle" style="text-align:center;">
                    Thank you for your Interest.<br />
                    Our Sales Manager will get in touch with you shortly.
                </h3>


                <a href="index.php" style="text-decoration: none;">
                    <!-- <h2 class="go-home">
                        <span class="" aria-hidden="true">
                            <i class="fa fa-arrow-left" aria-hidden="true"></i>
                        </span> 
                    </h2> -->
                </a>

                <?php
            }
            ?>

            </div>
        </div>
    </section>


    <section class="footer-sec" id="footer">
        <div class="container">
            <div class="foote-wrap">
                <img src="images/logo.png">
                <!--<img class="head-icon" src="images/head-icon.png">-->

                <div class="contacwrap">
                    <p>
                        For any inquiries, questions, or to register your interest, please contact us using the details
                        below
                    </p>

                    <!-- <ul class="address">
                        <li><i class="fas fa-phone"></i> 022 6144 6641</li>
                        <li><i class="fas fa-building"></i>GFR, Goregaon Mulund Link
                            Road, Near Fortis Hospital, Mulund (West), Mumbai - 400 080
                        </li>
                    </ul> -->
                    <ul class="reralist">
                        <li><img class="whatsapp" src="images/whatsapp.png" style="">&nbsp; <a href="tel:+919321490890"
                                class="fix-link"><b>+919321490890</b></li>

                    </ul>

                    <div class="address-line"></div>


                    <!-- <div style="width: 100%;height: 30px;"></div> -->

                    <ul class="partner">
                        <li><a href="https://www.instagram.com/getfitwithrihana/" target="_blank"> <img
                                    src="images/linkedin.png"></a></li>
                        <li><a href="https://www.facebook.com/getfitwithrihana" target="_blank"><img
                                    src="images/facebook.png" class=""></a></li>
                        <li><a href="https://www.youtube.com/channel/UCFB67EsuhivAYAdDpyl_V8Q/featured"
                                target="_blank"><img src="images/youtube.png" class=""></a></li>

                    </ul>

                    <div style="width: 100%;height: 30px;"></div>

                    <p class="copy-right">© GFR All Rights Reserved 2020.</p>

                </div>

            </div>
        </div>
    </section>

    <script src="js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="lightbox/light-box.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/wow.js"></script>

    <script src="js/jquery.validate.js"></script>
    <script src="js/mobilevalidate.js"></script>
    <script src="js/cookie.js"></script>
    <script src="js/popout.js"></script>



    <script type="text/javascript">
    jQuery(document).ready(function($) {
        // ---------------for model only-----
        $(".click-price").click(function() {
            $('#price-model').modal('show');
        });

        $(".interested").click(function() {
            $('#interested').modal('show');
        });
        $(".i-am").click(function() {
            $('#interested').modal('show');
        });

    });
    </script>

    <script>
    jQuery(document).ready(function($) {
        // Add smooth scrolling to all links
        $(".m-link").on('click', function(event) {

            // Make sure this.hash has a value before overriding default behavior
            if (this.hash !== "") {
                // Prevent default anchor click behavior
                event.preventDefault();

                // Store hash
                var hash = this.hash;

                // Using jQuery's animate() method to add smooth page scroll
                // The optional number (800) specifies the number of milliseconds it takes to scroll to the specified area

                $('html, body').animate({
                    scrollTop: $(hash).offset().top
                }, 800, function() {
                    // Add hash (#) to URL when done scrolling (default click behavior)
                    // window.location.hash = hash;
                });
            } // End if
        });

        $('.navbar-nav li').on('click', function() {
            $('.navbar-nav li.active').removeClass('active');
            $(this).addClass('active');
        });
        $(document).on('click', '.navbar-collapse.in', function(e) {
            if ($(e.target).is('a') && ($(e.target).attr('class') != 'dropdown-toggle')) {
                $(this).collapse('hide');
            }
        });
    });
    </script>

</body>

</html>